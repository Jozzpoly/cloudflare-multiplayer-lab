#!/usr/bin/env python3
import hashlib, json, os, pathlib, shutil, subprocess, sys, tempfile, time, urllib.request
from datetime import datetime, timezone

REPO = os.getenv('TERMINAL_REPOSITORY', 'Jozzpoly/cloudflare-multiplayer-lab')
OWNER_LOGIN = os.getenv('TERMINAL_OWNER_LOGIN', 'Jozzpoly')
ISSUE_NUMBER = int(os.getenv('TERMINAL_ISSUE_NUMBER', '41'))
RUNNER_BRANCH = os.getenv('TERMINAL_RUNNER_BRANCH', 'maintenance/repository-cleanup-v3-atomic-apply-runner-2026-09-10')
RUNNER_REF = f'refs/heads/{RUNNER_BRANCH}'
MAIN_REF = 'refs/heads/main'
ARCHIVE_REF = 'refs/heads/archive/repository-cleanup-v3-2026-09-10'
HELPER_REF = 'refs/heads/maintenance/repository-cleanup-v3-2026-09-10'
EXPECTED_MAIN = os.getenv('TERMINAL_EXPECTED_MAIN', '5305d25c7b544ad5e891dd3530bd79f5dc92206d')
BASE_ARCHIVE = os.getenv('TERMINAL_BASE_ARCHIVE', '85378de39a5d41058805e6c887ee977d855d2749')
EXPECTED_HELPER = os.getenv('TERMINAL_EXPECTED_HELPER', 'feb2cea533dc227d078b01e13113a32634ca9f78')
ANCHORS = [
    ('archive/world-v0-qualified-2p-baseline-2026-09-10', os.getenv('TERMINAL_QUALIFIED_SHA', '7755a668d7488f04ecbf42a00fbc96fcb978d544'), 'world-v0-qualified-2p-baseline-2026-09-10', 'Qualified fixed-two-player World V0 product checkpoint.'),
    ('archive/world-v0-final-delivery-2026-09-10', os.getenv('TERMINAL_FINAL_DELIVERY_SHA', 'fa5e45594f0c39ba4e96c13b4ef783bbaae1ba65'), 'world-v0-final-delivery-2026-09-10', 'Final qualified World V0 delivery checkpoint.'),
    ('archive/pre-safe-stop-main-2026-09-10', os.getenv('TERMINAL_PRE_SAFE_STOP_SHA', '829deef82c71780d2d661e7a7e82685739d7b23d'), 'world-v0-pre-safe-stop-main-2026-09-10', 'Canonical main immediately before the repository safe-stop campaign.'),
]
TERMINAL_TAG = 'repository-cleanup-terminal-2026-09-10'
PREPRUNE_TAG = 'repository-cleanup-v3-pre-prune-2026-09-10'
PREPRUNE_TARGET = os.getenv('TERMINAL_PREPRUNE_TARGET', '61f202289f0dcbde26cb5d72de67e7a46397c159')
PUBLISH_ARCHIVE = os.getenv('TERMINAL_PUBLISH_ARCHIVE', 'false').lower() == 'true'
ALLOW_APPLY = os.getenv('TERMINAL_ALLOW_APPLY', 'false').lower() == 'true'
TEST_MODE = os.getenv('TERMINAL_TEST_MODE', 'false').lower() == 'true'
OUT = pathlib.Path(os.getenv('TERMINAL_OUT_DIR', 'terminal-closure-out'))
ZERO_OID = '0' * 40
GRAPHQL_URL = 'https://api.github.com/graphql'
REST_API = 'https://api.github.com'


def run(args, *, cwd=None, input_text=None, check=True, env=None):
    p = subprocess.run(args, cwd=cwd, input=input_text, text=True, capture_output=True, env=env)
    if check and p.returncode != 0:
        raise RuntimeError(f"command failed ({p.returncode}): {' '.join(args)}\nstdout:\n{p.stdout}\nstderr:\n{p.stderr}")
    return p


def git(*args, cwd=None, input_text=None, check=True, env=None):
    return run(['git', *args], cwd=cwd, input_text=input_text, check=check, env=env)


def sha256_bytes(b): return hashlib.sha256(b).hexdigest()
def sha256_text(s): return sha256_bytes(s.encode())

def write_json(path, obj, compact=False):
    text = (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')) if compact else json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2)) + '\n'
    pathlib.Path(path).write_text(text, encoding='utf-8')
    return text


def live_refs(prefix):
    p = git('ls-remote', '--refs', 'origin', f'{prefix}/*')
    out = {}
    for line in p.stdout.splitlines():
        if not line.strip(): continue
        sha, ref = line.split('\t', 1)
        out[ref] = sha
    return out


def remote_ref(ref):
    p = git('ls-remote', '--refs', 'origin', ref)
    rows = [x for x in p.stdout.splitlines() if x.strip()]
    if not rows: return None
    if len(rows) != 1: raise RuntimeError(f'unexpected ls-remote rows for {ref}: {rows}')
    return rows[0].split('\t',1)[0]


def peel_remote_tag(name):
    p = git('ls-remote', 'origin', f'refs/tags/{name}', f'refs/tags/{name}^{{}}')
    obj = peeled = None
    for line in p.stdout.splitlines():
        if not line.strip(): continue
        sha, ref = line.split('\t',1)
        if ref.endswith('^{}'): peeled = sha
        elif ref == f'refs/tags/{name}': obj = sha
    return obj, peeled or obj


def assert_commit(sha): git('cat-file','-e',f'{sha}^{{commit}}')

def assert_ancestor(ancestor, descendant):
    p=git('merge-base','--is-ancestor',ancestor,descendant,check=False)
    if p.returncode != 0: raise RuntimeError(f'{ancestor} is not ancestor of {descendant}')


def canonical_json(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n'


def load_manifest():
    p=git('show', f'{BASE_ARCHIVE}:recovery-manifest.json')
    m=json.loads(p.stdout)
    if m.get('schema') != 'repository-cleanup-recovery-manifest-v3': raise RuntimeError('unexpected recovery manifest schema')
    if m.get('historicalBranchCount') != 167 or len(m.get('historicalBranches',[])) != 167: raise RuntimeError('unexpected historical branch count')
    return m



def history_external_payload_scan(unique_commits):
    gitlinks=[]
    blob_witness={}
    for commit in sorted(unique_commits):
        tree=git('ls-tree','-r',commit).stdout
        for line in tree.splitlines():
            if not line: continue
            meta, _, path=line.partition('\t')
            parts=meta.split()
            if len(parts)!=3: raise RuntimeError(f'unparsed ls-tree row: {line}')
            mode,typ,oid=parts
            if mode=='160000': gitlinks.append({'commit':commit,'path':path,'targetCommit':oid})
            if typ=='blob' and oid not in blob_witness: blob_witness[oid]={'commit':commit,'path':path}
    blob_ids=sorted(blob_witness)
    small=[]
    if blob_ids:
        p=git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input_text='\n'.join(blob_ids)+'\n')
        for line in p.stdout.splitlines():
            oid,typ,size_raw=line.split()
            size=int(size_raw)
            if typ=='blob' and size<=4096: small.append((oid,size))
    lfs=[]
    for oid,size in small:
        content=git('cat-file','blob',oid).stdout
        if not content.startswith('version https://git-lfs.github.com/spec/v1\n'): continue
        ext=None; declared=None
        for line in content.splitlines():
            if line.startswith('oid sha256:'): ext=line.split(':',1)[1]
            elif line.startswith('size '):
                try: declared=int(line.split()[1])
                except Exception: pass
        lfs.append({'blobOid':oid,'blobSize':size,**blob_witness[oid],'externalOid':ext,'declaredSize':declared})
    return {'uniqueCommitCountScanned':len(unique_commits),'distinctBlobCountScanned':len(blob_ids),'smallBlobCountInspected':len(small),'gitlinks':gitlinks,'lfsPointers':lfs}

def history_semantic_index(manifest):
    canonical=manifest['canonicalSha']
    tips=sorted(set(x['expectedSha'] for x in manifest['historicalBranches']))
    tip_data={}
    commit_subjects={}
    for tip in tips:
        assert_commit(tip)
        lp=git('log','--format=%H%x09%s',f'{canonical}..{tip}').stdout.strip()
        commits=[]
        if lp:
            for line in lp.splitlines():
                sha, _, subject=line.partition('\t')
                commits.append(sha); commit_subjects[sha]=subject
        tp=git('log','--format=','--name-only',f'{canonical}..{tip}').stdout
        touched=sorted(set(x for x in tp.splitlines() if x.strip()))
        tip_data[tip]={'commitCount':len(commits),'touchedPathCount':len(touched),'touchedPaths':touched,'commitShas':commits}
    refs=[]
    transient_global=set()
    for row in sorted(manifest['historicalBranches'], key=lambda x:x['ref']):
        h=tip_data[row['expectedSha']]
        net=set(row.get('changedFiles') or [])
        recent=set(c['sha'] for c in row.get('recentBranchOnlyCommits') or [])
        transient=[p for p in h['touchedPaths'] if p not in net]
        omitted=[s for s in h['commitShas'] if s not in recent]
        transient_global.update(transient)
        refs.append({
          'ref':row['ref'],'expectedSha':row['expectedSha'],'proofClass':row.get('proofClass'),
          'branchOnlyCommitCount':row.get('branchOnlyCommitCount'),
          'manifestChangedFileCount':row.get('changedFileCount'),
          'historyTouchedPathCount':h['touchedPathCount'],
          'transientOnlyPathCount':len(transient),
          'omittedCommitCountVsV3RecentFive':len(omitted),
          'netZeroButHistoricalWork':row.get('changedFileCount')==0 and h['touchedPathCount']>0,
          'historyTopLevelAreas':sorted(set(p.split('/')[0] for p in h['touchedPaths'] if p)),
          'manifestTopLevelAreas':row.get('topLevelAreas') or [],
          'transientOnlyPaths':transient,
        })
    unique_commits=set(commit_subjects)
    payload=history_external_payload_scan(unique_commits)
    if payload['gitlinks'] or payload['lfsPointers']:
        raise RuntimeError(f"history-wide external payload blocker discovered at terminal preparation: gitlinks={len(payload['gitlinks'])} lfs={len(payload['lfsPointers'])}")
    summary={
      'historicalBranchCount':len(refs),'distinctTipCount':len(tips),'uniqueCommitSubjectCount':len(commit_subjects),
      'branchesWithAnyTransientOnlyPath':sum(r['transientOnlyPathCount']>0 for r in refs),
      'branchesWithCommitsBeyondRecentFive':sum(r['omittedCommitCountVsV3RecentFive']>0 for r in refs),
      'netZeroBranchesWithHistoricalWork':sum(r['netZeroButHistoricalWork'] for r in refs),
      'distinctTransientOnlyPathCount':len(transient_global),
      'historyWideUniqueCommitCountScanned':payload['uniqueCommitCountScanned'],
      'historyWideDistinctBlobCountScanned':payload['distinctBlobCountScanned'],
      'historyWideSmallBlobCountInspected':payload['smallBlobCountInspected'],
      'historyWideGitlinkCount':len(payload['gitlinks']),'historyWideLfsPointerCount':len(payload['lfsPointers']),
    }
    obj={
      'schema':'multi-world-recovery-semantic-index-v1', 'repository':REPO,
      'generatedFrom':{
        'historyAuditRunId':34523544614,'historyAuditArtifactId':10170613068,
        'historyAuditArtifactDigest':'sha256:d30174b224800eb2ef3b9b59e17869614bbc3bb4a194448f6d781a92c67e4fee',
        'historyWideExternalPayloadRunId':34523320913,'historyWideExternalPayloadArtifactId':10170528863,
        'historyWideExternalPayloadArtifactDigest':'sha256:eec4532878af99dbc3423267e4ff42743ad4e391bc886211400d76d9cae3153d',
        'recoveryManifestSha256':'sha256:a779e80273b434f5d1844aca5f4ce13e0a9d33dd4fc9b8779c1abbc0e9d68ee0'
      },
      'frozenCanonicalSha':canonical,'summary':summary,
      'interpretation':{
        'exactRecoveryAuthority':'recovery-manifest.json + aggregate archive ancestry',
        'semanticDiscoveryAuthority':'this index is history-aware and supplements, not replaces, exact recovery identity',
        'v3Gap':'net tip diff + five recent commits can underdescribe transient historical work',
        'externalPayloadRetrospective':'separate history-wide scan found zero Git LFS pointers and zero gitlinks/submodules in the retired history'
      },
      'refs':refs,'distinctTips':tip_data,'commitSubjects':commit_subjects,'historyWideExternalPayloadScan':payload,
    }
    return obj


def semantic_md(index):
    refs=index['refs']; s=index['summary']; canonical=index['frozenCanonicalSha']
    netzero=[r for r in refs if r['netZeroButHistoricalWork']]
    top_commits=sorted(refs,key=lambda r:(r['branchOnlyCommitCount'] or 0), reverse=True)[:12]
    top_trans=sorted(refs,key=lambda r:r['transientOnlyPathCount'], reverse=True)[:12]
    L=['# Multi_World Recovery Semantic Index','',
       'Purpose: make retired research/history discoverable by meaning without weakening exact Git recovery identity. This supplements `recovery-manifest.json`; it does not replace it.','',
       '## Evidence binding','',
       '- history-aware audit run `34523544614`: SUCCESS; artifact `10170613068`, digest `sha256:d30174b224800eb2ef3b9b59e17869614bbc3bb4a194448f6d781a92c67e4fee`;',
       '- history-wide external-payload audit run `34523320913`: SUCCESS; artifact `10170528863`, digest `sha256:eec4532878af99dbc3423267e4ff42743ad4e391bc886211400d76d9cae3153d`;',
       f'- frozen canonical: `{canonical}`;',
       '- exact recovery manifest SHA-256: `a779e80273b434f5d1844aca5f4ce13e0a9d33dd4fc9b8779c1abbc0e9d68ee0`.','',
       '## What the retrospective found','',
       f"- **{s['historicalBranchCount']}** retired ref names / **{s['distinctTipCount']}** distinct tips;",
       '- **443** unique commits in the retired-history union relative to frozen canonical;',
       '- **867** distinct blobs scanned by the external-payload retrospective;',
       '- **0** historical Git LFS pointers and **0** gitlinks/submodules;',
       f"- **{s['branchesWithAnyTransientOnlyPath']}/167** refs contain transient-only paths hidden by final net diff;",
       f"- **{s['branchesWithCommitsBeyondRecentFive']}/167** refs contain branch-only commits beyond the five recent commits shown by Cleanup Kit v3;",
       f"- **{s['netZeroBranchesWithHistoricalWork']}** refs have `changedFileCount = 0` despite real historical work;",
       f"- **{s['distinctTransientOnlyPathCount']}** distinct transient-only paths are absent from the v3 tip-centric semantic summary.",'',
       '## Important semantic witnesses','']
    for r in netzero:
        L += [f"### `{r['ref']}`",'',f"- exact tip: `{r['expectedSha']}`;",f"- branch-only commits: **{r['branchOnlyCommitCount']}**;",f"- history-touched paths: **{r['historyTouchedPathCount']}**;",f"- v3 final changed-file count: **{r['manifestChangedFileCount']}**;",f"- historical top-level areas: `{', '.join(r['historyTopLevelAreas'])}`;",f"- inspect full history with exact range `{canonical}..{r['expectedSha']}` or the machine index.",'']
    L += ['## Largest historical lines by branch-only commit count','', '| Retired ref | Tip | Commits | History paths | v3 net files | Transient-only |','|---|---|---:|---:|---:|---:|']
    for r in top_commits:
        L.append(f"| `{r['ref']}` | `{r['expectedSha'][:12]}…` | {r['branchOnlyCommitCount']} | {r['historyTouchedPathCount']} | {r['manifestChangedFileCount']} | {r['transientOnlyPathCount']} |")
    L += ['','## Largest transient-history gaps','', '| Retired ref | Transient-only paths | Omitted commits vs v3 recent-five |','|---|---:|---:|']
    for r in top_trans: L.append(f"| `{r['ref']}` | {r['transientOnlyPathCount']} | {r['omittedCommitCountVsV3RecentFive']} |")
    L += ['','## Recovery workflow','',
          '1. Resolve a retired branch name to its exact historical tip with `CATALOG.md` / `recovery-manifest.json`.',
          '2. Use `MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.json` to inspect all history-touched paths and branch-only commit subjects, including work later reverted before tip.',
          '3. Inspect/recover by exact SHA from the aggregate archive lineage. Semantic metadata is navigation; exact object reachability remains recovery truth.',
          '4. Same-repository archive reachability is not off-site disaster recovery; preserve the qualified bundle/evidence separately.','',
          '## Design lesson retained','',
          'A final tree diff answers “what differs at the end”; it does not answer “what happened on this research line.” Future cleanup tooling should model those as separate questions.','']
    return '\n'.join(L)


def closure_md(runner_sha, index_sha, index_md_sha):
    return f'''# Repository cleanup terminal closure candidate

Status: **PREPARED / OWNER STOP UNTIL EXACT TERMINAL TRANSACTION AUTHORIZATION**

## Preserved authority

- canonical live project line at preparation: `{EXPECTED_MAIN}`;
- qualified fixed-2P product: `{ANCHORS[0][1]}`;
- final qualified delivery: `{ANCHORS[1][1]}`;
- pre-safe-stop main: `{ANCHORS[2][1]}`;
- pre-prune aggregate anchor: `{PREPRUNE_TARGET}`;
- Cleanup Kit v3 verified seal: `4d2fae1a18613f0c90c4b242edfa68eb26fd66a2`;
- previous aggregate archive parent: `{BASE_ARCHIVE}`;
- cleanup helper exact tip preserved in archive ancestry: `{EXPECTED_HELPER}`;
- terminal runner exact tip preserved by this archive candidate: `{runner_sha}`.

## Bulk prune evidence

The 167-ref destructive prune was Owner-authorized and completed through guarded atomic apply/postflight. Exact recovery rehearsal restored 167/167 selected refs after self-contained bundle creation and aggressive Git GC.

The final Owner-supplied Cleanup Kit v3.0.0 distribution was later verified: all six runtime modules exactly match those executed in Multi_World. Donor red-team nevertheless found real v3 blind spots; therefore this terminal closure does not rely on v3's old helper-lifecycle semantics.

## History-aware recovery interface

This archive adds:

- `MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.json` — machine-readable history-aware branch/tip/commit/path discovery;
- `MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.md` — compact human navigation;
- JSON SHA-256: `{index_sha}`;
- Markdown SHA-256: `{index_md_sha}`.

Exact recovery identity remains `recovery-manifest.json` plus archive ancestry. The semantic index supplements exact identity; it does not redefine it.

History-wide retrospective found zero Git LFS pointers and zero gitlinks/submodules in the retired history.

## Terminal ref semantics

Current-best final topology is two live branches: `main` plus this aggregate recovery archive.

Three immutable World V0 checkpoint branch names are candidates for atomic conversion into annotated tags at their exact commits. The cleanup helper and terminal runner are cleanup apparatus candidates for retirement after their exact tips are preserved here.

The final destructive transaction is intentionally **not embedded in this commit** because its digest includes this archive candidate identity and deterministic annotated-tag objects. It is emitted by the unchanged terminal runner and recorded in run evidence / issue #41.

No generic continuation authorizes that transaction. The obsolete earlier helper-retirement digest `36a281e7ea81b2e998d0c5169cae975817e541bd7132b314acb1f349e3331af0` must never be reused.

## Platform boundary

Historical GitHub Actions registry entries may remain marked active even after source branch deletion. Zero historical-residue executions were observed after the bulk-prune cutoff. This is tracked as platform/UI hygiene, not conflated with Git recoverability or destructive safety.

Same-repository Git preservation does not constitute off-site disaster recovery.
'''


def make_archive_candidate(runner_sha, index_json, index_md):
    index_text=canonical_json(index_json)
    idx_sha=sha256_text(index_text); md_sha=sha256_text(index_md)
    closure=closure_md(runner_sha, idx_sha, md_sha)
    with tempfile.NamedTemporaryFile(prefix='mw-index-', delete=False) as tf: index_file=tf.name
    try:
        env=os.environ.copy(); env['GIT_INDEX_FILE']=index_file
        try: os.unlink(index_file)
        except FileNotFoundError: pass
        git('read-tree',BASE_ARCHIVE,env=env)
        for path,text in [('MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.json',index_text),('MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.md',index_md),('CLOSURE.md',closure)]:
            blob=git('hash-object','-w','--stdin',input_text=text).stdout.strip()
            git('update-index','--add','--cacheinfo',f'100644,{blob},{path}',env=env)
        tree=git('write-tree',env=env).stdout.strip()
    finally:
        try: os.unlink(index_file)
        except FileNotFoundError: pass
    ts=git('show','-s','--format=%ct',runner_sha).stdout.strip()
    ce=os.environ.copy(); ce.update({'GIT_AUTHOR_NAME':'Repository Terminal Closure','GIT_AUTHOR_EMAIL':'repository-terminal-closure@invalid.local','GIT_COMMITTER_NAME':'Repository Terminal Closure','GIT_COMMITTER_EMAIL':'repository-terminal-closure@invalid.local','GIT_AUTHOR_DATE':f'@{ts} +0000','GIT_COMMITTER_DATE':f'@{ts} +0000'})
    msg='Prepare history-aware terminal recovery archive\n\nterminal-runner: '+runner_sha+'\ncanonical-main: '+EXPECTED_MAIN+'\nprevious-archive: '+BASE_ARCHIVE+'\nsemantic-index-sha256: '+idx_sha+'\nsemantic-index-md-sha256: '+md_sha+'\n'
    candidate=git('commit-tree',tree,'-p',BASE_ARCHIVE,'-p',EXPECTED_MAIN,'-p',runner_sha,input_text=msg,env=ce).stdout.strip()
    return candidate, idx_sha, md_sha, index_text, index_md, closure


def make_tag_object(name,target,message,runner_sha):
    ts=git('show','-s','--format=%ct',runner_sha).stdout.strip()
    tagger=f'Repository Terminal Closure <repository-terminal-closure@invalid.local> {ts} +0000'
    body=f'object {target}\ntype commit\ntag {name}\ntagger {tagger}\n\n{message}\n'
    return git('mktag', input_text=body).stdout.strip()


def prepare_tags(archive_candidate, runner_sha):
    specs=[]
    for branch,sha,name,msg in ANCHORS:
        obj=make_tag_object(name,sha,msg,runner_sha); specs.append({'ref':f'refs/tags/{name}','name':name,'objectSha':obj,'targetSha':sha,'message':msg})
    msg='Terminal aggregate recovery archive for the Multi_World 2026-09-10 repository closure. Presence of this tag is the single-use terminal-consumption marker.'
    obj=make_tag_object(TERMINAL_TAG,archive_candidate,msg,runner_sha)
    specs.append({'ref':f'refs/tags/{TERMINAL_TAG}','name':TERMINAL_TAG,'objectSha':obj,'targetSha':archive_candidate,'message':msg})
    return specs


def transaction_obj(runner_sha,archive_candidate,tags,index_sha,index_md_sha):
    deletes=[{'ref':f'refs/heads/{b}','expectedSha':s} for b,s,_,_ in ANCHORS]
    deletes += [{'ref':HELPER_REF,'expectedSha':EXPECTED_HELPER},{'ref':RUNNER_REF,'expectedSha':runner_sha}]
    creates=[{k:t[k] for k in ('ref','objectSha','targetSha')} for t in tags]
    retains=[{'ref':MAIN_REF,'expectedSha':EXPECTED_MAIN},{'ref':ARCHIVE_REF,'expectedSha':archive_candidate}]
    ref_updates=[]
    for d in deletes:
        ref_updates.append({'kind':'DELETE','name':d['ref'],'beforeOid':d['expectedSha'],'afterOid':ZERO_OID,'force':True})
    for t in creates:
        ref_updates.append({'kind':'CREATE_ANNOTATED_TAG','name':t['ref'],'beforeOid':ZERO_OID,'afterOid':t['objectSha'],'force':False})
    for r in retains:
        ref_updates.append({'kind':'RETAIN_ASSERT','name':r['ref'],'beforeOid':r['expectedSha'],'afterOid':r['expectedSha'],'force':False})
    if len(ref_updates)!=11 or len({u['name'] for u in ref_updates})!=11:
        raise RuntimeError('terminal ref-update cardinality/uniqueness invariant failed')
    return {
      'schema':'repository-terminal-transaction-v2','transport':'github-graphql-updateRefs-atomic-cas',
      'repository':REPO,'ownerLogin':OWNER_LOGIN,'issueNumber':ISSUE_NUMBER,
      'runnerSha':runner_sha,'archiveBeforeSha':BASE_ARCHIVE,'archiveFinalSha':archive_candidate,
      'canonicalMainSha':EXPECTED_MAIN,'semanticIndexSha256':index_sha,'semanticIndexMarkdownSha256':index_md_sha,
      'deleteRefs':deletes,'createAnnotatedTags':creates,'retainExactRefs':retains,'refUpdates':ref_updates,
      'preconditions':{'expectedLiveHeadCountBefore':7,'expectedLiveHeadCountAfter':2,'allCreatedTagsMustBeAbsentBefore':True,'terminalTagIsSingleUseConsumptionMarker':True,'retainAssertionsAreInsideAtomicUpdateRefs':True},
      'recoveryAssertions':{'helperTipMustBeAncestorOfArchive':EXPECTED_HELPER,'runnerTipMustBeAncestorOfArchive':runner_sha,'all167ManifestTipsMustExistInFreshMirror':True},
      'obsoleteTransactionDoNotUse':'36a281e7ea81b2e998d0c5169cae975817e541bd7132b314acb1f349e3331af0'
    }


def expected_heads_before(runner_sha, archive_sha):
    d={MAIN_REF:EXPECTED_MAIN,ARCHIVE_REF:archive_sha,HELPER_REF:EXPECTED_HELPER,RUNNER_REF:runner_sha}
    for b,s,_,_ in ANCHORS: d[f'refs/heads/{b}']=s
    return d


def verify_heads_exact(expected):
    got=live_refs('refs/heads')
    if got != expected:
        missing=sorted(set(expected)-set(got)); unexpected=sorted(set(got)-set(expected)); moved=sorted(r for r in set(expected)&set(got) if expected[r]!=got[r])
        raise RuntimeError(f'live head mismatch missing={missing} unexpected={unexpected} moved={[(r,expected[r],got[r]) for r in moved]}')
    return got


def verify_preparation_heads(runner_sha, archive_candidate):
    got=live_refs('refs/heads')
    base=expected_heads_before(runner_sha, BASE_ARCHIVE)
    cand=expected_heads_before(runner_sha, archive_candidate)
    if got != base and got != cand:
        raise RuntimeError(f'preparation head mismatch: got={got} expected_base={base} expected_candidate={cand}')
    return got, ('candidate' if got == cand else 'base')


def verify_preprune_tag():
    obj, peeled=peel_remote_tag(PREPRUNE_TAG)
    if not obj or peeled != PREPRUNE_TARGET: raise RuntimeError(f'pre-prune tag mismatch obj={obj} peeled={peeled}')
    return {'objectSha':obj,'peeledTarget':peeled}


def auth_present(exact_token):
    if TEST_MODE:
        return os.getenv('TERMINAL_TEST_AUTH_TOKEN','').strip() == exact_token
    token=os.getenv('GITHUB_TOKEN','')
    if not token: raise RuntimeError('GITHUB_TOKEN missing for owner authorization lookup')
    found=[]; page=1
    while True:
        url=f'https://api.github.com/repos/{REPO}/issues/{ISSUE_NUMBER}/comments?per_page=100&page={page}'
        req=urllib.request.Request(url,headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'multi-world-terminal-closure'})
        with urllib.request.urlopen(req,timeout=30) as resp: rows=json.loads(resp.read())
        for c in rows:
            if (c.get('user') or {}).get('login') == OWNER_LOGIN and (c.get('body') or '').strip() == exact_token: found.append(c.get('id'))
        if len(rows)<100: break
        page+=1
        if page>50: raise RuntimeError('authorization pagination bound exceeded')
    if len(found)>1: raise RuntimeError(f'duplicate exact owner authorization comments: {found}')
    return len(found)==1


def publish_archive(candidate):
    current=remote_ref(ARCHIVE_REF)
    if current == candidate: return 'already-published'
    if current != BASE_ARCHIVE: raise RuntimeError(f'archive drift before publish: {current}, expected {BASE_ARCHIVE} or candidate {candidate}')
    git('push',f'--force-with-lease={ARCHIVE_REF}:{BASE_ARCHIVE}','origin',f'{candidate}:{ARCHIVE_REF}')
    if remote_ref(ARCHIVE_REF)!=candidate: raise RuntimeError('archive publish postflight mismatch')
    return 'published'


def verify_tag_absence(tags):
    present=[]
    for t in tags:
        if remote_ref(t['ref']): present.append(t['ref'])
    if present: raise RuntimeError(f'transaction-created tags unexpectedly already exist before apply: {present}')


def install_local_tag_refs(tags):
    for t in tags: git('update-ref',t['ref'],t['objectSha'])


def github_headers(token):
    return {'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'multi-world-terminal-closure','Content-Type':'application/json'}


def http_json(url, *, token, method='GET', payload=None):
    data=None if payload is None else json.dumps(payload,separators=(',',':')).encode()
    req=urllib.request.Request(url,data=data,method=method,headers=github_headers(token))
    try:
        with urllib.request.urlopen(req,timeout=45) as resp:
            raw=resp.read().decode('utf-8')
            return resp.status, (json.loads(raw) if raw else None)
    except Exception as e:
        body=''
        if hasattr(e,'read'):
            try: body=e.read().decode('utf-8','replace')
            except Exception: pass
        raise RuntimeError(f'GitHub HTTP failure {method} {url}: {e}; body={body[:4000]}') from e


def ensure_remote_annotated_tag_objects(tags):
    if TEST_MODE:
        return [{'name':t['name'],'objectSha':t['objectSha'],'mode':'test-local-object'} for t in tags]
    token=os.getenv('GITHUB_TOKEN','')
    if not token: raise RuntimeError('GITHUB_TOKEN missing for annotated tag object preparation')
    prepared=[]
    for t in tags:
        # GitHub REST creates only the tag object, not refs/tags/*; therefore OWNER_STOP still has no tag ref mutation.
        ts=int(git('show','-s','--format=%ct',os.getenv('GITHUB_SHA') or git('rev-parse','HEAD').stdout.strip()).stdout.strip())
        date=datetime.fromtimestamp(ts,timezone.utc).isoformat().replace('+00:00','Z')
        payload={'tag':t['name'],'message':t['message'],'object':t['targetSha'],'type':'commit','tagger':{'name':'Repository Terminal Closure','email':'repository-terminal-closure@invalid.local','date':date}}
        _, row=http_json(f'{REST_API}/repos/{REPO}/git/tags',token=token,method='POST',payload=payload)
        got=(row or {}).get('sha')
        if got != t['objectSha']:
            raise RuntimeError(f'GitHub annotated tag object identity mismatch for {t["name"]}: local={t["objectSha"]} github={got}')
        prepared.append({'name':t['name'],'objectSha':got,'mode':'github-unreferenced-tag-object'})
    return prepared


def transaction_observed_state(transaction):
    state={}
    for u in transaction['refUpdates']:
        state[u['name']]=remote_ref(u['name'])
    return state


def transaction_expected_before(transaction):
    return {u['name']:(None if u['beforeOid']==ZERO_OID else u['beforeOid']) for u in transaction['refUpdates']}


def transaction_expected_after(transaction):
    return {u['name']:(None if u['afterOid']==ZERO_OID else u['afterOid']) for u in transaction['refUpdates']}


def apply_atomic_test_backend(transaction,tags,runner_sha):
    # Local Git backend validates lifecycle/fail-closed behavior, but cannot emulate no-op RETAIN_ASSERT transport.
    before=expected_heads_before(runner_sha,transaction['archiveFinalSha'])
    verify_heads_exact(before); verify_tag_absence(tags)
    install_local_tag_refs(tags)
    args=['push','--atomic']
    for d in transaction['deleteRefs']: args.append(f"--force-with-lease={d['ref']}:{d['expectedSha']}")
    args += ['origin']
    for t in tags: args.append(f"{t['ref']}:{t['ref']}")
    for d in transaction['deleteRefs']: args.append(f":{d['ref']}")
    p=git(*args,check=False)
    (OUT/'test-atomic-push.stdout.txt').write_text(p.stdout); (OUT/'test-atomic-push.stderr.txt').write_text(p.stderr)
    if p.returncode != 0:
        verify_heads_exact(before); verify_tag_absence(tags)
        raise RuntimeError(f'test atomic terminal push failed with zero-change postcheck confirmed: {p.stderr}')


def apply_github_atomic(transaction,tags,runner_sha):
    if TEST_MODE:
        return apply_atomic_test_backend(transaction,tags,runner_sha)
    token=os.getenv('GITHUB_TOKEN','')
    if not token: raise RuntimeError('GITHUB_TOKEN missing for GitHub GraphQL terminal apply')
    before=transaction_expected_before(transaction)
    observed=transaction_observed_state(transaction)
    if observed != before:
        raise RuntimeError(f'terminal atomic preflight mismatch: expected={before} observed={observed}')
    # Exact tag object SHAs must already exist in GitHub object storage; refs remain absent until updateRefs.
    ensure_remote_annotated_tag_objects(tags)
    # Re-probe after object upload; object creation must not alter refs.
    observed2=transaction_observed_state(transaction)
    if observed2 != before:
        raise RuntimeError(f'ref state drifted during tag-object preparation: expected={before} observed={observed2}')
    _, repo=http_json(f'{REST_API}/repos/{REPO}',token=token)
    repository_id=(repo or {}).get('node_id')
    if not repository_id: raise RuntimeError('repository node_id unavailable')
    mutation='mutation UpdateRefs($input: UpdateRefsInput!) { updateRefs(input: $input) { clientMutationId } }'
    variables={'input':{'repositoryId':repository_id,'refUpdates':[{k:u[k] for k in ('name','beforeOid','afterOid','force')} for u in transaction['refUpdates']]}}
    request={'query':mutation,'variables':variables}
    write_json(OUT/'graphql-updateRefs-request.json',{'variables':variables,'mutationName':'UpdateRefs'})
    try:
        _, response=http_json(GRAPHQL_URL,token=token,method='POST',payload=request)
        write_json(OUT/'graphql-updateRefs-response.json',response or {})
        if (response or {}).get('errors'):
            raise RuntimeError('GitHub GraphQL updateRefs returned errors: '+json.dumps(response['errors'],ensure_ascii=False))
    except Exception as e:
        post=transaction_observed_state(transaction)
        if post == before:
            write_json(OUT/'graphql-failure-postcheck.json',{'status':'ZERO_CHANGE_CONFIRMED','before':before,'after':post,'error':str(e)})
            raise RuntimeError(f'GitHub atomic terminal mutation failed; ZERO_CHANGE_CONFIRMED: {e}') from e
        write_json(OUT/'graphql-failure-postcheck.json',{'status':'AMBIGUOUS_OR_CHANGED_STATE','before':before,'after':post,'error':str(e)})
        raise RuntimeError(f'GitHub atomic terminal mutation failed and state changed/ambiguous: {e}; observed={post}') from e
    after=transaction_expected_after(transaction)
    post=transaction_observed_state(transaction)
    if post != after:
        raise RuntimeError(f'GitHub updateRefs returned success but exact terminal ref postflight mismatched: expected={after} observed={post}')
    print('PASS_GITHUB_TERMINAL_UPDATE_REFS_ATOMIC_CAS')


def verify_terminal(transaction,tags,runner_sha,*,fresh_mirror=True):
    expected={MAIN_REF:EXPECTED_MAIN,ARCHIVE_REF:transaction['archiveFinalSha']}
    got=verify_heads_exact(expected)
    tag_rows={}
    for t in tags:
        obj,peeled=peel_remote_tag(t['name'])
        if obj!=t['objectSha'] or peeled!=t['targetSha']: raise RuntimeError(f"tag mismatch {t['name']}: obj={obj} peeled={peeled}")
        tag_rows[t['name']]={'objectSha':obj,'peeledTarget':peeled}
    assert_ancestor(EXPECTED_HELPER,transaction['archiveFinalSha']); assert_ancestor(runner_sha,transaction['archiveFinalSha']); assert_ancestor(EXPECTED_MAIN,transaction['archiveFinalSha'])
    for _,sha,_,_ in ANCHORS: assert_ancestor(sha,transaction['archiveFinalSha'])
    # semantic files on archive
    idx=git('show',f"{transaction['archiveFinalSha']}:MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.json").stdout
    md=git('show',f"{transaction['archiveFinalSha']}:MULTI_WORLD_RECOVERY_SEMANTIC_INDEX.md").stdout
    if sha256_text(idx)!=transaction['semanticIndexSha256']: raise RuntimeError('semantic JSON digest mismatch in archive')
    if sha256_text(md)!=transaction['semanticIndexMarkdownSha256']: raise RuntimeError('semantic Markdown digest mismatch in archive')
    fm=None
    if fresh_mirror:
        td=tempfile.mkdtemp(prefix='mw-terminal-mirror-')
        try:
            remote=git('remote','get-url','origin').stdout.strip()
            git('clone','--mirror',remote,td)
            git('fsck','--full',cwd=td)
            p=git('for-each-ref','--format=%(refname) %(objectname)','refs/heads',cwd=td)
            mh={line.split(' ',1)[0]:line.split(' ',1)[1] for line in p.stdout.splitlines() if line.strip()}
            if mh!=expected: raise RuntimeError(f'fresh mirror heads mismatch {mh}')
            manifest=json.loads(git('show',f"{ARCHIVE_REF}:recovery-manifest.json",cwd=td).stdout)
            for row in manifest['historicalBranches']: git('cat-file','-e',f"{row['expectedSha']}^{{commit}}",cwd=td)
            for sha in [EXPECTED_HELPER,runner_sha,EXPECTED_MAIN,*[a[1] for a in ANCHORS]]: git('cat-file','-e',f'{sha}^{{commit}}',cwd=td)
            for t in tags:
                obj=git('rev-parse',t['ref'],cwd=td).stdout.strip(); peeled=git('rev-parse',f"{t['ref']}^{{}}",cwd=td).stdout.strip()
                if obj!=t['objectSha'] or peeled!=t['targetSha']: raise RuntimeError(f"fresh mirror tag mismatch {t['name']}")
            fm={'status':'PASS','historicalRefsVerified':len(manifest['historicalBranches']),'headCount':len(mh)}
        finally: shutil.rmtree(td,ignore_errors=True)
    return {'status':'PASS','heads':got,'tags':tag_rows,'freshMirror':fm}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    runner_sha=os.getenv('GITHUB_SHA') or git('rev-parse','HEAD').stdout.strip()
    assert_commit(runner_sha); assert_commit(EXPECTED_MAIN); assert_commit(BASE_ARCHIVE); assert_commit(EXPECTED_HELPER)
    for _,sha,_,_ in ANCHORS: assert_commit(sha)
    preprune=verify_preprune_tag()
    manifest=load_manifest()
    idx=history_semantic_index(manifest); idx_md=semantic_md(idx)
    candidate,idx_sha,idx_md_sha,idx_text,idx_md,closure=make_archive_candidate(runner_sha,idx,idx_md)
    assert_commit(candidate)
    # Candidate is deterministic and must already carry every authority we intend to retire.
    assert_ancestor(BASE_ARCHIVE,candidate); assert_ancestor(EXPECTED_MAIN,candidate); assert_ancestor(runner_sha,candidate); assert_ancestor(EXPECTED_HELPER,candidate)
    for _,sha,_,_ in ANCHORS: assert_ancestor(sha,candidate)
    tags=prepare_tags(candidate,runner_sha)
    txn=transaction_obj(runner_sha,candidate,tags,idx_sha,idx_md_sha)
    txn_text=canonical_json(txn); digest=sha256_text(txn_text)
    auth=f'REPO_CLEANUP_TERMINAL_APPLY:{REPO}:{digest}'
    write_json(OUT/'terminal-transaction.json',txn)
    (OUT/'terminal-transaction.canonical.json').write_text(txn_text)
    (OUT/'authorization-token.txt').write_text(auth+'\n')
    (OUT/'semantic-index.json').write_text(idx_text)
    (OUT/'semantic-index.md').write_text(idx_md)
    (OUT/'closure.md').write_text(closure)
    write_json(OUT/'prepared-tag-objects.json',tags)
    prep={'schema':'repository-terminal-preparation-v1','runnerSha':runner_sha,'canonicalMainSha':EXPECTED_MAIN,'baseArchiveSha':BASE_ARCHIVE,'archiveCandidateSha':candidate,'transactionSha256':digest,'authorizationToken':auth,'semanticIndexSha256':idx_sha,'semanticIndexMarkdownSha256':idx_md_sha,'prePruneTag':preprune,'publishArchiveEnabled':PUBLISH_ARCHIVE,'applyEnabled':ALLOW_APPLY}
    write_json(OUT/'preparation.json',prep)

    # Single-use terminal marker short-circuits all mutation on re-runs after success.
    terminal_obj, terminal_peeled = peel_remote_tag(TERMINAL_TAG)
    expected_terminal = next(t for t in tags if t['name']==TERMINAL_TAG)
    if terminal_obj is not None:
        if terminal_obj != expected_terminal['objectSha'] or terminal_peeled != candidate: raise RuntimeError('terminal tag exists but does not match this deterministic transaction')
        verdict=verify_terminal(txn,tags,runner_sha,fresh_mirror=True)
        write_json(OUT/'terminal-verification.json',verdict)
        print(f'ALREADY_TERMINAL_PASS transaction={digest} archive={candidate}')
        return

    # Before archive publication the seven live heads must match the known topology; archive may already be the deterministic candidate on an authorization rerun.
    _, archive_state = verify_preparation_heads(runner_sha, candidate)
    for t in tags: 
        if t['name'] != TERMINAL_TAG and remote_ref(t['ref']) is not None: raise RuntimeError(f'checkpoint tag already exists unexpectedly: {t["ref"]}')

    if PUBLISH_ARCHIVE:
        state=publish_archive(candidate); print(f'ARCHIVE_{state.upper()} {candidate}')
        remote_tag_objects=ensure_remote_annotated_tag_objects(tags)
        write_json(OUT/'remote-annotated-tag-objects.json',remote_tag_objects)
        print(f'REMOTE_ANNOTATED_TAG_OBJECTS_VERIFIED count={len(remote_tag_objects)}')
    else:
        print(f'DRY_PREP_ARCHIVE_NOT_PUBLISHED candidate={candidate}')

    # After optional non-destructive archive fast-forward, verify ancestry and exact head topology.
    archive_live = candidate if PUBLISH_ARCHIVE else BASE_ARCHIVE
    verify_heads_exact(expected_heads_before(runner_sha, archive_live))
    if PUBLISH_ARCHIVE:
        assert_ancestor(BASE_ARCHIVE,candidate); assert_ancestor(EXPECTED_MAIN,candidate); assert_ancestor(runner_sha,candidate); assert_ancestor(EXPECTED_HELPER,candidate)
        for _,sha,_,_ in ANCHORS: assert_ancestor(sha,candidate)

    has_auth=auth_present(auth)
    prep['authorizationPresent']=has_auth
    write_json(OUT/'preparation.json',prep)
    if not has_auth:
        print(f'OWNER_STOP transaction={digest}')
        print(auth)
        return
    if not ALLOW_APPLY:
        print(f'AUTH_PRESENT_BUT_APPLY_DISABLED transaction={digest}')
        return
    if not PUBLISH_ARCHIVE:
        raise RuntimeError('apply enabled but archive publication disabled')

    # Final race-safe preflight and atomic conversion/delete transaction.
    verify_heads_exact(expected_heads_before(runner_sha,candidate)); verify_tag_absence(tags)
    apply_github_atomic(txn,tags,runner_sha)
    verdict=verify_terminal(txn,tags,runner_sha,fresh_mirror=True)
    verdict['transactionSha256']=digest; verdict['runnerSha']=runner_sha; verdict['archiveSha']=candidate
    write_json(OUT/'terminal-verification.json',verdict)
    print(f'PASS_TERMINAL_ATOMIC_APPLY_AND_FRESH_MIRROR transaction={digest} archive={candidate}')

if __name__=='__main__':
    try: main()
    except Exception as e:
        OUT.mkdir(parents=True,exist_ok=True)
        (OUT/'failure.txt').write_text(str(e)+'\n')
        print('TERMINAL_CLOSURE_FAIL',e,file=sys.stderr)
        sys.exit(1)
